<?php 
ob_start();
error_reporting(0);
$nomor = $_GET['nomor'];
    function create_url($string, $ext='.html'){     
        $replace = '-';         
        $string = strtolower($string);     
        //replace / and . with white space     
        $string = preg_replace("/[\/\.]/", " ", $string);     
        $string = preg_replace("/[^a-z0-9_\s-]/", "", $string);     
        //remove multiple dashes or whitespaces     
        $string = preg_replace("/[\s-]+/", " ", $string);     
        //convert whitespaces and underscore to $replace     
        $string = preg_replace("/[\s_]/", $replace, $string);     
        //limit the slug size     
        $string = substr($string, 0, 100);     
        //text is generated     
        return ($ext) ? $string.$ext : $string; 
    }    
function slugToText($slug='') {
  $slug = trim($slug);
  if (empty($slug)) return '';
    $slug = str_replace('-', ' ', $slug);
    $slug = str_replace(',', ' ', $slug);
    $slug = ucwords($slug);
    return $slug;
}
    $a = ['pelem1', 'pelem2', 'pelem3', 'pelem4', 'pelem5', 'pelem6', 'pelem7', 'pelem8', 'pelem9', 'pelem10', 'pelem11', 'pelem12', 'pelem13', 'pelem14', 'pelem15', 'pelem16', 'pelem17', 'pelem18', 'pelem19', 'pelem20', 'pelem21', 'pelem22', 'pelem23', 'pelem24', 'pelem25', 'pelem26', 'pelem27', 'pelem28', 'pelem29', 'pelem30', 'pelem31', 'pelem32', 'pelem33', 'pelem34'];
    $website = $a[mt_rand(0, count($a) - 1)];

$rows = file("keto.txt");
$len = count($rows);
$rand = [];
while (count($rand) < 5970) {
    $r = rand(0, $len);
    if (!in_array($r, $rand)) {
        $rand[] = $r;
    }
}
/**
 * Spintax - A helper class to process Spintax strings.
 * @name Spintax
 * @author Jason Davis - https://www.codedevelopr.com/
 * Tutorial: https://www.codedevelopr.com/articles/php-spintax-class/
 */
class Spintax
{
    public function process($text)
    {
        return preg_replace_callback(
            '/\{(((?>[^\{\}]+)|(?R))*)\}/x',
            array($this, 'replace'),
            $text
        );
    }
    public function replace($text)
    {
        $text = $this->process($text[1]);
        $parts = explode('|', $text);
        return $parts[array_rand($parts)];
    }
}
		$spintax = new Spintax();
	$string_title = '{Review of|Preview of|Big Sale|Cheap Price|Best Price|Promotion Price|Hot Promo|Deal Promo|Best Promo|Best Discount|Best Promotion|Best Deal|Best Offer|Discount Sale}';
	$diskon = '{50|60|70|80|51|61|71|81|52|62|72|82|53|63|73|54|64|74|55|65|75|56|66|76|57|67|77|58|68|78|59|69|79|47|48|49}';
	$domain = $_SERVER['SERVER_NAME'];
	$jam = date('c');
?>
<?php echo '<?xml version="1.0" encoding="UTF-8"?>'; ?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
<?php
foreach ($rand as $r) {
    $csv = $rows[$r];
    $data = str_getcsv($csv);
	$spin = $spintax->process($string_title);
	$spin2 = $spintax->process($diskon);
		//input
$url = create_url($data[0]);
$url2 = strtolower($spin);
$url2 = str_replace(" ", "-", $url2);
    // now do whatever you want with $data, which is one random row of your CSV
    echo "
	<url>
    <loc>https://$domain/$url2-$spin2-off-$url</loc>
		<priority>0.5</priority>
		<lastmod>$jam</lastmod>
		<changefreq>weekly</changefreq>
    </url>";
	header('Content-Type: application/xml; charset=utf-8');
}
?>		
</urlset>