<?php
ob_start();
error_reporting(0);
require('libs/load.php');

if(isset($_GET['q']))
{		
	$q = str_replace("-", " ", strtolower($_GET['q']));
	$result = search_images($q);
  	$canonical = curPageURL();
	/*
	if(strpos($canonical, ".html") === false){	
	header("Location: http://jobspapa.com/". $_GET['q'] . ".html");	
	}
	/*	
	if($result == NULL){
	header("Location: http://jobspapa.com/");
	}
	*/	
	$title = ucwords($q);	
	//$kue = stuffing();
	//print_r($result);
	//$load->assign('kue', $kue);
	
$spintax = new Spintax();

	
	$string_title2 = '{Limited|Best} {promotion|offer|discount|big sale|sale} {get it|checkit|claim it} {now|right now}';
	$spintax->process($string_title2);
	$load->assign('spin2', $spintax->process($string_title2));
$link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 
                "https" : "http") . "://" . $_SERVER['HTTP_HOST'] .  
                $_SERVER['REQUEST_URI']; 
				$load->assign('link', $link); 
	$www = $_SERVER['REQUEST_URI'];			
	$judul = str_replace("-", " ", $www);
	$judul = str_replace("/", "", $judul);
	$judul = str_replace(".html", "", $judul);
	$load->assign('judul', $judul);				
	//Random FAKE rating star
$persen = array("4","4.2","4.5","4.6","4.8");
$rating = $persen[rand(0,4)];
$ulasan = array("1570", "2371", "50242", "23600", "87373", "23453", "25430", "23221", "22191", "22453", "22123", "22111");
$review = $ulasan[rand(0,11)];
	$load->assign('rating', $rating);
	$load->assign('review', $review);
	
	$listkeyword = listkeyword();
	$load->assign('listkeyword', $listkeyword);  
	$load->assign('canonical', $canonical);    	   
	$load->assign('result', $result);   
	$load->assign('title', $title);   
	  
	$load->display('search.tpl');

}elseif(isset($_GET['kw'])){
	$q = str_replace("-", " ", $_GET['kw']);
	$num = $_GET['no'];

	$result = views($q, $num);
	//print_r($result);
	//exit();
	$kw = strtolower($result[0]['title']);
	$related = search_images($kw);
	$canonical = curPageURL();
	$keyword = ucwords($q);
	$listkeyword = listkeyword();
	$link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 
                "https" : "http") . "://" . $_SERVER['HTTP_HOST'] .  
                $_SERVER['REQUEST_URI']; 
				$load->assign('link', $link); 
	$www = $_SERVER['REQUEST_URI'];			
	$judul = str_replace("-", " ", $www);
	$judul = str_replace("/", " ", $judul);
	$judul = str_replace(".html", "", $judul);
	$load->assign('judul', $judul);	
	//Random FAKE rating star
$persen = array("4","4.2","4.5","4.6","4.8");
$rating = $persen[rand(0,4)];
$ulasan = array("1570", "2371", "50242", "23600", "87373", "23453", "25430", "23221", "22191", "22453", "22123", "22111");
$review = $ulasan[rand(0,11)];
	$load->assign('rating', $rating);
	$load->assign('review', $review);
	
	$load->assign('listkeyword', $listkeyword);
	
	$load->assign('keyword', $keyword);
	$load->assign('canonical', $canonical);
	$load->assign('result', $result[0]);
	$load->assign('related', $related);	
	$load->display('single.tpl');

}elseif(isset($_GET['url'])){
	
	$url = $_GET['url'];	
	header("Location: http://".$url);	

}else{
	$f_contents = file("keto.txt");
	$line = $f_contents[array_rand($f_contents)];
	$q = $line;	
	$bings = search_images($q);
	$load->assign('kw', $line);
	//print_r($bings);
	//exit();
	$canonical = curPageURL();
	$listkeyword = listkeyword();
	//$kue = stuffing();
	//$load->assign('kue', $kue);
	
	$load->assign('listkeyword', $listkeyword);    	   
	$load->assign('berita', $line);    	   
	$load->assign('canonical', $canonical);    	   
	$load->assign('result', $bings);    	   
	$load->display('index.tpl'); 

}
?>
