<?php
/*
 *     Smarty plugin
 * -------------------------------------------------------------
 * File:        function.term.php
 * Type:        function
 * Name:        term
 * Description: This TAG creates a "x minute ago" like timestamp.
 *
 * -------------------------------------------------------------
 * @license GNU Public License (GPL)
 *
 * -------------------------------------------------------------
 * Parameter:
 * - ts         = the email to fetch the gravatar for (required)
 * -------------------------------------------------------------
 * Example usage:
 *
 * <div>{term num="12" ren="1"} ago </div>
 */
function smarty_function_term($params, &$smarty) {
	return $params[num]." ".$params[ren];
}