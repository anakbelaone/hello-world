<?php
include "Smarty.class.php";

$load = new Smarty;

//include "config.php";

include "function.php"; 
