<?php 
ob_start();
if (isset($_POST['src']))
{
	$pattern 	 = '/(\w+)/';
	$mantap 	 = preg_match ($pattern, $_POST['src'], $pertama);
	$arr_replace = array('!','?','@','-','"',"'",'(',')','[',']',':',',','.','/','#',"\\",'$','&','*','+','~','>','<','=','|','_');
    $str_url          = str_replace($arr_replace, "", $_POST['src']);
    //$str_url          = str_replace($arr_replace, "", $mantap);
	print_r($mantap);
    $str_url          = str_replace(" ", "-", $str_url );
    $str_url          = str_replace("--", "-", $str_url);
	$str_url		  = rtrim($str_url, "-");
	$str_url		  = strtolower($str_url);
	
    header("Location: http://viethot.top/". $str_url . ".html");
}

function kilobit($bytes) 
    {
    $size = $bytes / 1024;
    if($size < 1024)
        {
        $size = number_format($size, 2);
        $size .= ' kB';
        } 
    else 
        {
        if($size / 1024 < 1024) 
            {
            $size = number_format($size / 1024, 2);
            $size .= ' MB';
            } 
        else if ($size / 1024 / 1024 < 1024)  
            {
            $size = number_format($size / 1024 / 1024, 2);
            $size .= ' GB';
            } 
        }
    return $size;
    }
	
function curPageURL()
{
	$pageURL = 'http';
	$pageURL .= "://";
	if ($_SERVER["SERVER_PORT"] != "80") {
	$pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
	} else {
	$pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
	}
	return $pageURL;
}

function get_details($term)
{
	$getimagelink = explode("/", str_replace("http://thaihots.top/", "", $term));
	//$imagelink = str_replace("*", "/", $getimagelink[1]);
	$image = str_replace("id", "", $getimagelink[0]);
	$title = str_replace(".html", "", $getimagelink[1]);
	$title = preg_replace("![^a-z0-9]+!i", " ", strtolower($title));
	$linktitle = str_replace(" ", "-", $title);
	$title = ucwords($title);
	
	$tb[] = array("title" => $title ,
				"linktitle" => $linktitle ,
				"image" => $image);	
	return $tb;			
}
	
function get_url($url, $ref, $ua)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    //curl_setopt($ch, CURLOPT_PROXY, '74.86.97.180:9870');
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_USERAGENT, $ua);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_REFERER, $ref);
    $index = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);
    return $index;
}

function badwords($term)
{
	$arr	= explode("\n",file_get_contents("bad/badwords.txt"));
	$title	= str_replace($arr, "", $term);
	return $title;    
}

function check($kw)
{
    $fail = explode("\n",file_get_contents("bad/badwords.txt"));
	foreach ($fail as $source) {
        if (strpos($kw, $source) !== false)
            return true;
    }
    return false;
}
/**
 * Spintax - A helper class to process Spintax strings.
 * @name Spintax
 * @author Jason Davis - https://www.codedevelopr.com/
 * Tutorial: https://www.codedevelopr.com/articles/php-spintax-class/
 */
class Spintax
{
    public function process($text)
    {
        return preg_replace_callback(
            '/\{(((?>[^\{\}]+)|(?R))*)\}/x',
            array($this, 'replace'),
            $text
        );
    }
    public function replace($text)
    {
        $text = $this->process($text[1]);
        $parts = explode('|', $text);
        return $parts[array_rand($parts)];
    }
}


function search_images($q)
{	
	$list_ua = ['Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:5.1.1.42)','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.23.1.15)','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.1.1.15)','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.2.1.18)','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.1.1.16)','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.1.1.25)','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:5.1.1.15)'];
    $ua_acak = $list_ua[mt_rand(0, count($list_ua) - 1)];
	$ua = $ua_acak;
	$q = urlencode(strtolower($q));
	$url_images = "https://www.bing.com/images/async?q=$q%20site:amazon.com&view=detail&async=content&first=1&count=35&IID=images&adlt=moderate";
    $index = get_url($url_images, "", $ua);
	$str1  = '<div class="imgpt"><a class="iusc" style="';
    $str2 = 'amazon.com</a></div></div></div>';
    $str_image1 = 'turl&quot;:&quot;';
    $str_image2 = '&quot;,&quot;md5&quot';
	$str_title1 = 't&quot;:&quot;';
	$str_title2 = '&quot;,&quot;mid';
	$str_file1 = 'hon"><span class="nowrap">';
	$str_file2 = '</span><div class="lnkw">';
	$str_source1 = 'purl&quot;:&quot;';
	$str_source2 = '&quot;,&quot;murl';
	$parse = explode($str1, $index); 
    $sum   = count($parse);
	$term = str_replace("+", " ", strtolower($q));
   if (!check($term)) {
    //echo $term;
	for ($i = 1; $i < $sum; $i++) {
		$gets = explode($str2, $parse[$i]);
		$nomor = $i;
		$image = explode($str_image1, $gets[0]);
		$image = explode($str_image2, $image[1]);
		$image = $image[0];
		$source = explode($str_source1, $gets[0]);
		$source = explode($str_source2, $source[1]);
		
		$title = explode($str_title1, $gets[0]);
		$title = explode($str_title2, $title[1]);
		$title = preg_replace("![^a-z0-9]+!i", " ", strtolower($title[0]));		
		$title = preg_replace("/[0-9]/", "", $title);
		$arr_q = array("buy","online","cheap","gnc","amazon","ebay","wallmart","rakuten","walmart","jpg","png","jpeg","http","www",".html","ajilbab","genuardis","pelauts","serbagunamarine","com","net","org","info","blogspot");
		$title = str_replace($arr_q, "", $title);
		$title = str_replace("  ", " ", $title);
		$title = explode(" ", $title);	
		$title = implode(" ", array_unique($title));
		$title = preg_replace(array('/\b\w{1,2}\b/','/\s+/'),array('',' '),$title); //hapus kurang dari 3 karakter	
		$title = ltrim($title, " ");
		$title = rtrim($title, " ");
		$title = str_replace("amp", "and", $title);	
		$keyword = urldecode(strtolower($q));
		$linkeyword = str_replace(" ", "-", $keyword);
		$spintax = new Spintax();
	$string_title = '{Review of|Preview of|Big Sale|Cheap Price|Best Price|Promotion Price|Hot Promo|Deal Promo|Best Promo|Best Discount|Best Promotion|Best Deal|Best Offer|Discount Sale}';
	$diskon = '{50|60|70|80|51|61|71|81|52|62|72|82|53|63|73|54|64|74|55|65|75|56|66|76|57|67|77|58|68|78|59|69|79|47|48|49}';
		$linkurl = str_replace(" ", "-", $title);
		
		$filetype = explode($str_file1, $gets[0]);
		$filetype = explode($str_file2, $filetype[1]);
		
		$src	= preg_match('@^(?:http://)?([^/]+)@i', $source[0], $link);
		$src 	= str_replace("www.", "", $link[1]);
		$srclink = str_replace("", "", $source[0]);
		
		$arr_images[] = array(				
				"title" => ucwords($title),
				"nomor" => $nomor,
				"linkurl" => $linkurl,
				"linkeyword" => $linkeyword,
				"filetype" => $filetype[0],
				"image" => $image,
				"src" => $src,
				"source" => $source[0],
				"spin3" => $spintax->process($string_title),
				"diskon" => $spintax->process($diskon),
				"srclink" => $srclink
			);					
	}	
	return $arr_images; 
	}
	else header('Location: /'); 
}

function views($q, $i = 10){
                
	$q = str_replace("-", "+", $_GET['kw']);
	$i = $_GET['no'];
	
	$list_ua = ['Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:5.1.1.42)','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.23.1.15)','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.1.1.15)','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.2.1.18)','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.1.1.16)','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.1.1.25)','Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:5.1.1.15)'];
    $ua_acak = $list_ua[mt_rand(0, count($list_ua) - 1)];
	$ua = $ua_acak;
	$url_images = "https://www.bing.com/images/async?q=$q%20site:amazon.com&view=detail&async=content&first=1&count=35&IID=images&adlt=moderate";
	
    $index = get_url($url_images, "", $ua);
   
	$str1  = '<div class="imgpt"><a class="iusc" style="';
    $str2 = 'amazon.com</a></div></div></div>';
    $str_image1 = 'murl&quot;:&quot;';
    $str_image2 = '&quot;,&quot;turl&quot';
	$str_title1 = 't&quot;:&quot;';
	$str_title2 = '&quot;,&quot;mid';
	$str_file1 = 'hon"><span class="nowrap">';
	$str_file2 = '</span><div class="lnkw">';
	$str_source1 = 'purl&quot;:&quot;';
	$str_source2 = '&quot;,&quot;murl';
	$parse = explode($str1, $index);
	 
    $sum   = count($parse);
	$term = str_replace("+", " ", strtolower($q));
   if (!check($term)) {
    //echo $term;
	//for ($i = 1; $i < $sum; $i++) {
		$gets = explode($str2, $parse[$i]);
		$nomor = $i;
		$image = explode($str_image1, $gets[0]);
		$image = explode($str_image2, $image[1]);
		$image = $image[0];
		$source = explode($str_source1, $gets[0]);
		$source = explode($str_source2, $source[1]);
		
		$title = explode($str_title1, $gets[0]);
		$title = explode($str_title2, $title[1]);
		$title = preg_replace("![^a-z0-9]+!i", " ", strtolower($title[0]));		
		$title = preg_replace("/[0-9]/", "", $title);
		$arr_q = array("buy","online","cheap","gnc","amazon","ebay","wallmart","rakuten","walmart","jpg","png","jpeg","http","www",".html","ajilbab","genuardis","pelauts","serbagunamarine","com","net","org","info","blogspot");
		$title = str_replace($arr_q, "", $title);
		$title = str_replace("  ", " ", $title);
		$title = explode(" ", $title);	
		$title = implode(" ", array_unique($title));
		$title = preg_replace(array('/\b\w{1,2}\b/','/\s+/'),array('',' '),$title); //hapus kurang dari 3 karakter	
		$title = ltrim($title, " ");
		$title = rtrim($title, " ");
		$title = str_replace("amp", "and", $title);	
		$keyword = urldecode(strtolower($q));
		$linkeyword = str_replace(" ", "-", $keyword);
		$spintax = new Spintax();
	$string_title = '{Review of|Preview of|Big Sale|Cheap Price|Best Price|Promotion Price|Hot Promo|Deal Promo|Best Promo|Best Discount|Best Promotion|Best Deal|Best Offer|Discount Sale}';
	$diskon = '{50|60|70|80|51|61|71|81|52|62|72|82|53|63|73|54|64|74|55|65|75|56|66|76|57|67|77|58|68|78|59|69|79|47|48|49}';

		$linkurl = str_replace(" ", "-", $title);
		
		$filetype = explode($str_file1, $gets[0]);
		$filetype = explode($str_file2, $filetype[1]);
		
		$src	= preg_match('@^(?:http://)?([^/]+)@i', $source[0], $link);
		$src 	= str_replace("www.", "", $link[1]);
		$srclink = str_replace("", "", $source[0]);
				
		$arr_images[] = array(				
				"title" => ucwords($title),
				"nomor" => $nomor,
				"linkurl" => $linkurl,
				"linkeyword" => $linkeyword,
				"filetype" => $filetype[0],
				"image" => $image,
				"source" => $source[0],
				"spin3" => $spintax->process($string_title),
				"diskon" => $spintax->process($diskon),
				"src" => $src,
				"srclink" => $srclink
			);			
	return $arr_images; 
	}
	else header('Location: /'); 
}

function listkeyword()
{
	$arr_kw = array("home","funny pictures","funny tattoo","funny quotes","funny pics","funny people","funny meme","funny jokes","funny girl","funny baby");
	foreach($arr_kw as $item)
	{
	$title = strtolower($item);
	$link = explode(" ", $title);
	if($title === "home")
		{
		$link = "http://viethot.top/";
		}	
	else{
		$link = "http://viethot.top/".str_replace(" ", "-", $title).".html";	
		}
	
	$curpage = curPageURL();
	if($link != $curpage){
		$class = "";
		}
	else{
		$class = "current_page_item";
		}
	
	$arr[] = array("title" => $title,
			"link" => $link,	
			"class" => $class);	
	}
	return $arr;

}

/*
function se_ref()
{
    $ref = $_SERVER['HTTP_REFERER'];
    $SE  = array(
        '.baidu.',
        '.google.',
        '/search?',
        'images.google.',
        'web.info.com',
        'search.',
        'blogspot.',
        'wordpress.',
        'facebook.',
        'twitter.',
        'del.icio.us/search',
        'soso.com',
        '/search/',
        '.yahoo.',
        '.bing.',
        'localhost'
    );
  reach ($SE as $source) {
        if (strpos($ref, $source) !==alse)
            return true;
    }
    returnalse;
}
function stuffing()
{
    $cookie = md5(rand(1, 10));
    if ((!isset($_COOKIE['useraagents'])) && se_ref()) {
        setcookie('useraagents', $cookie, time() + 86400);
        $url = "
	<script type='text/javascript'>
	var papa = document.getElementById('topads');
	var link = papa.getElementsByTagName('a');
	var tujuan = document.getElementsByTagName('a');
	var i = 0;
	var ses = 0;
	for (x in tujuan){
	i++; 
	tujuan[x].onmouseover =unction(){
	 ses++; 
	if (ses > (link.length - 2))
	ses = 0; 
	 }
	}

	function makeFrame(link) { 
	   ifrm = document.createElement(\"IFRAME\"); 
	   ifrm.setAttribute(\"src\", ''+link+''); 
	   ifrm.style.width = 0+\"px\"; 
	   ifrm.style.height = 0+\"px\"; 
	   document.body.appendChild(ifrm); 
	}

	</script>
		<script type=\"text\/javascript\">
		if (window.jstiming) window.jstiming.load.tick('widgetJsBefore');
		</script>
		<script>makeFrame('http://bit.ly/183X1KS');</script>

	";
        
    } else
        $url = "";
    return $url;
}
*/
?>
