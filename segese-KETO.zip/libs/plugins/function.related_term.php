<?php
/*
 *     Smarty plugin
 * -------------------------------------------------------------
 * File:        function.related_term.php
 * Type:        function
 * Name:        term
 * Description: menampilkan term.
 *
 * -------------------------------------------------------------
 * @license GNU Public License (GPL)
 *
 * -------------------------------------------------------------
 * Parameter:
 * - term        = term searc (required)
 * -------------------------------------------------------------
 * Example usage:
 *
 * <div>{related_term term="12"} </div>
 */
function smarty_function_related_term($params, &$smarty) {

	if ($params[term] != "")
	{
		
		$nm = get_related($params[term],$params[li],$params[re]);
		$nm_c = count($nm);
		//echo $nm_c;
		//print_r($nm);
		if ($nm_c > 0)
		{
		$a .= "<ul>";
			foreach ($nm as $n)
			{
				$fileimages = $n[title];
				$fileimages = preg_replace("/[^A-Za-z0-9]/", " ", $fileimages);
				$fileimages = preg_replace("/\s+/", " ", $fileimages);
				$fileimages = strtolower($fileimages);
				$fileimages = str_replace(" ", "-", $fileimages);
				$fileimages = trim($fileimages);
				$icondir    = 'http://iappgeeks.com/appz/images/thumb/' . $fileimages .'-'. $n[itunes_id] .'.jpg';
				
				//echo "Title : ".$icondir; 
				//$a .= "<li><img src='" .$icondir . "' /><a href=".gen_url_post($n[id],$n[title])." >".$n[title]."</a></li>";
				$a .= '
										<tr>
							<td valign="top" width="86">
								<table width="86" border="0" cellpadding="0" cellspacing="0" height="70">
								<tbody>
								<tr>
									<td valign="middle" width="70" align="center" background="http://iappgeeks.com/images/pic_bg.png">
										<a href="'.gen_url_post($n[id],$n[title]).'">
										<img src="'.$icondir.'" title="'.$n[title].'" alt="'.$n[title].'" width="52" border="0" height="52"></a>
									</td>
									<td background="http://iappgeeks.com/images/pic_bg_1.png">
										 &nbsp;
									</td>
								</tr>
								</tbody>
								</table>
							</td>
							
							<td valign="top" width="450">
								<table width="100%" border="0" cellpadding="1" cellspacing="0">
								<tbody>
								<tr>
									<td class="artist_name">
										<a href="'.gen_url_post($n[id],$n[title]).'" title="'.$n[publisher].'">'.$n[publisher].'</a>
									</td>
								</tr>
								<tr>
									<td class="composition_name">
										<a href="'.gen_url_post($n[id],$n[title]).'" title="'.$n[title].'">'.$n[title].'</a>
									</td>
								</tr>
								<tr>
									<td class="bitrate_info">
										<img src="http://mp3.vulgaire.com/images/'.$n[rating].'stars.gif">
									</td>
								</tr>
								<tr>
									<td>
										<table width="100%" border="0" cellpadding="0" cellspacing="0">
										<tbody>
										<tr>
											<td width="20">
												<img src="http://iappgeeks.com/images/pic_point.png" width="15" height="15">
											</td>
											<td class="download_link">
												<a href="'.gen_url_post($n[id],$n[title]).'">Download</a>
											</td>
										</tr>
										</tbody>
										</table>
									</td>
								</tr>
								</tbody>
								</table>
							</td>
						</tr>
				';
			
			}
		$a .= "</ul>";
		//$a .= $nm_c;
		}
		else
		{
			$a = "<p>No Related</p>";
		}
	}
	
	return $a;
}