<?php
/*
 *     Smarty plugin
 * -------------------------------------------------------------
 * File:        function.term.php
 * Type:        function
 * Name:        term
 * Description: This TAG creates a "x minute ago" like timestamp.
 *
 * -------------------------------------------------------------
 * @license GNU Public License (GPL)
 *
 * -------------------------------------------------------------
 * Parameter:
 * - ts         = the email to fetch the gravatar for (required)
 * -------------------------------------------------------------
 * Example usage:
 *
 * <div>{term num="12" ren="1"} </div>
 */
function smarty_function_term($params, &$smarty) {
	//return $params[num]." ".$params[ren];
	$nm = get_term($params[num] , $params[ren]);
	foreach ($nm as $n)
	{
		if ($a != "") $a .=" , ";
		$a .= "<a href=".get_url_term($n[term])." >".ucwords($n[term])."</a>";
	}
	return $a;
}