<?php
/*
 *     Smarty plugin
 * -------------------------------------------------------------
 * File:        function.term_post.php
 * Type:        function
 * Name:        term
 * Description: menampilkan term.
 *
 * -------------------------------------------------------------
 * @license GNU Public License (GPL)
 *
 * -------------------------------------------------------------
 * Parameter:
 * - id        = id (required)
 * -------------------------------------------------------------
 * Example usage:
 *
 * <div>{term_post id="12"} </div>
 */
function smarty_function_term_post($params, &$smarty) {

	if ($params[id] != "")
	{
		$nm = get_term_post($params[id],$params[li]);
		$nm_c = count($nm);
		//echo $nm_c;
		//var_dump($nm);
		if ($nm_c > 0)
		{
		$a .= "<ul>";
			foreach ($nm as $n)
			{
				$a .= "<li><a href=".get_url_term($n[term_post])." >".$n[term_post]."</a></li>";
			}
		$a .= "</ul>";
		//$a .= $nm_c;
		}
	}
	
	return $a;
}