<?php

//mysql server
define('MYSLQ_HOST', 'localhost');

//mysql username
define('MYSQL_USER', 'root');

//mysql pass
define('MYSQL_PASS', '');

//mysql database
define('MYSQL_DATABASE', 'asd');

$user_admin = "admin";
$pass_admin = "admin";

//load config
//$load->force_compile = true;

//enabel debuging
//$load->debugging = true;

//$load->caching = true;

//$load->cache_lifetime = 120;

//$load->force_compile = true;
